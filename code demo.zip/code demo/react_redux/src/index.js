import React from 'react';
import ReactDOM from 'react-dom';
import Provider from 'react-redux/lib/components/Provider';
import { App } from './contains/app';
import store from './redux/store';

// 定义渲染根组件标签的函数
const render = () => {
  ReactDOM.render(
    <Provider store={store}>
      <App />
    </Provider>,
    document.getElementById('root')
  );
};
// 初始化渲染
render();

// 注册(订阅)监听, 一旦状态发生改变, 自动重新渲染
// store.subscribe(render);
