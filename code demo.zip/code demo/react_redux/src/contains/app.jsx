import {increment,decrement} from '../redux/actions'
import {connect} from 'react-redux'
import { Counter } from '../components/counter'

// 向外暴露连接App组件的包装组件
export const App= connect(
    state => ({count: state}),
    {increment, decrement}
  )(Counter)